import React from "react";
import styled from "styled-components";
import pix from "../Assets/postman.png";
import { AiOutlineDown } from "react-icons/ai";
import { RiSearchLine } from "react-icons/ri";
const Header = () => {
  return (
    <Container>
      <Wrapper>
        <Left>
          <img src={pix} alt="" />
          <Hold ml="20px">
            <p>Product</p>
            <Icon>
              <AiOutlineDown />
            </Icon>
          </Hold>
          <p>Pricing</p>
          <Hold ml="17px">
            <p>Enterprise</p>
            <Icon>
              <AiOutlineDown />
            </Icon>
          </Hold>
          <Hold ml="17px">
            <p>Resources and support</p>
            <Icon>
              <AiOutlineDown />
            </Icon>
          </Hold>
          <p>Explore</p>
        </Left>
        <Right>
          <Main>
            <RiSearchLine />
            <input type="text" placeholder="Search postman" />
          </Main>
          <ButtonHold>
            <Button
              wd="60px"
              bg="white"
              br="1px solid black"
              cl="black"
              mr="10px"
            >
              Sign in
            </Button>
            <Button wd="110px" bg="#ff6c37" br="none" cl="white" mr="">
              Sign up for free
            </Button>
          </ButtonHold>
        </Right>
      </Wrapper>
    </Container>
  );
};

export default Header;

const Container = styled.div`
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  position: sticky;
  top: 0;
  background-color: white;
  z-index: 2;
`;
const Wrapper = styled.div`
  width: 98%;
  height: 50px;
  display: flex;
  align-items: center;
  justify-content: space-between;
`;

const Left = styled.div`
  display: flex;
  align-items: center;

  img {
    height: 36px;
  }
  p {
    margin: 0;
    font-size: 15px;
    font-weight: 700;
    color: #2f5253;
    margin-left: 26px;
  }
`;
const Right = styled.div`
  display: flex;
  align-items: center;
`;
const Hold = styled.div<{ ml: string }>`
  display: flex;
  margin-left: ${({ ml }) => ml};
  p {
    margin: 0;
    font-size: 15px;
    font-weight: 700;
    color: #2f5253;
  }
`;
const Icon = styled.div`
  font-weight: 700;
  color: #2f5253;
  margin-top: 4px;
  font-size: 12px;
  margin-left: 4px;
`;

const Main = styled.div`
  width: 150px;
  height: 40px;
  background-color: #f2f2f2;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 6px;
  padding-left: 10px;
  margin-right: 160px;
  input {
    width: 80%;
    height: 100%;
    border: none;
    background-color: transparent;
    outline: none;
    padding-left: 10px;
  }
`;

const ButtonHold = styled.div`
  display: flex;
`;
const Button = styled.button<{
  wd: string;
  bg: string;
  br: string;
  cl: string;
  mr: string;
}>`
  width: ${({ wd }) => wd};
  height: 35px;
  border-radius: 5px;
  border: ${({ br }) => br};
  font-size: 13px;
  background-color: ${({ bg }) => bg};
  cursor: pointer;
  color: ${({ cl }) => cl};
  margin-right: ${({ mr }) => mr};
`;
