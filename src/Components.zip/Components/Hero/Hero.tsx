import React from "react";
import styled from "styled-components";
import pix from "../Assets/right.png";
const Hero = () => {
  return (
    <Container>
      <Left>
        <h2>
          Build <br /> APIs together
        </h2>
        <p>
          Over 20 million developers use Postman. Get <br /> started by signing
          up or downloading the desktop app.
        </p>
        <Hold>
          <input type="text" placeholder="Finbarr@example.com" />
          <button>Sign up for free</button>
        </Hold>
        <div>Download the desktop app</div>

        <Mama>
          <Box></Box>
          <Box></Box>
          <Box></Box>
        </Mama>
      </Left>
      <Right>
        <img src={pix} alt="" />
      </Right>
    </Container>
  );
};

export default Hero;

const Container = styled.div`
  width: 100%;
  height: 500px;
  /* background-color: red; */
  display: grid;
  grid-template-columns: 1fr 2fr;
  grid-template-rows: repeat(2, 500px);
`;

const Left = styled.div`
  display: flex;
  justify-content: center;
  flex-direction: column;
  margin-left: 80px;
  div {
    font-size: 13px;
    margin-top: 20px;
    color: #6b6b6b;
    font-weight: bold;
  }

  p {
    font-size: 17px;
    line-height: 1.7;
  }
  h2 {
    margin: 0;
    margin-top: 90px;
  }
`;
const Right = styled.div`
  img {
    width: 100%;
    height: 100%;
    object-fit: cover;
  }
`;

const Hold = styled.div`
  width: 370px;
  height: 40px;
  display: flex;
  background-color: red;
  border-radius: 5px;
  overflow: hidden;
  margin-top: 15px;
  input {
    width: 65%;
    border: 1px solid #ff6c37;
    outline: none;
    padding-left: 10px;

    ::placeholder {
      font-weight: bold;
    }
  }
  button {
    width: 35%;
    background-color: #ff6c37;
    color: white;
    border: none;
    cursor: pointer;
  }
`;

const Mama = styled.span`
  display: flex;
  width: 150px;
  justify-content: center;
`;
const Box = styled.div`
  width: 35px;
  height: 35px;
  background-color: #f5f5f5;
  border-radius: 5px;
  margin-right: 10px;
`;
