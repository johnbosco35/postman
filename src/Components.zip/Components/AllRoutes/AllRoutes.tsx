import React from "react";
import { useRoutes } from "react-router-dom";
import HomeScreem from "../Hero/HomeScreem";
import SignUp from "../SignUp";
const AllRoutes = () => {
  const element = useRoutes([
    {
      path: "/signup",
      element: <SignUp />,
    },
    {
      path: "/",
      element: <HomeScreem />,
    },
  ]);

  return element;
};

export default AllRoutes;
